# Design System Document: The Midnight Library

## 1. Overview & Creative North Star
**Creative North Star: "The Velvet Editorial"**
This design system rejects the clinical, "app-like" feel of standard digital interfaces in favor of a sophisticated, editorial experience. It is designed to evoke the tactile comfort of a private library at midnight. We move beyond the "template" look by utilizing intentional asymmetry, deep tonal layering, and high-contrast typography scales that prioritize storytelling over mere utility. 

The goal is to make the user feel as though they are stepping into a curated sanctuary. We achieve this through "The Breathing Layout"—using expansive whitespace (Spacing 16-24) and soft, overlapping elements that mimic the natural flow of a physical book.

---

## 2. Colors & Surface Philosophy
The palette is built on a foundation of "Atmospheric Navy" with "Warm Amber" highlights to guide the eye like a reading lamp in a dark room.

### The "No-Line" Rule
**Strict Mandate:** 1px solid borders for sectioning are prohibited. Boundaries must be defined solely through background color shifts. To separate a hero section from a grid, transition from `surface` (#071327) to `surface_container_low` (#101b30). If elements feel lost, increase the contrast between container tiers rather than reaching for a stroke.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine paper or frosted glass.
*   **Base:** `surface` (#071327)
*   **Floating Layers:** Use `surface_container` (#142034) or `surface_container_high` (#1f2a3f) to lift content.
*   **The Glass & Gradient Rule:** For main Playback CTAs or Hero backgrounds, use a linear gradient from `primary` (#bac8dc) to `primary_container` (#0c1a29) at a 135-degree angle. This adds "visual soul" that flat hex codes cannot provide.

---

## 3. Typography
We use a bi-font system to balance "Classic Literature" with "Modern Utility."

*   **Editorial Expression:** We use **Newsreader** for all `display` and `headline` roles. This serif typeface brings the "Sense of Storytelling" to the forefront. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) for high-end impact.
*   **Functional Clarity:** We use **Inter** for `title`, `body`, and `label` roles. This ensures that metadata—like "12 hours remaining"—is hyper-readable at a glance.
*   **Hierarchy Note:** Use `tertiary` (#ffb781) for `label-md` to highlight "New Release" or "Bestseller" tags, creating a warm, premium callout.

---

## 4. Elevation & Depth
In "The Velvet Editorial," depth is felt, not seen. We use tonal layering to create hierarchy without the clutter of traditional shadows.

### The Layering Principle
Instead of a shadow, place a `surface_container_lowest` (#030e22) card on a `surface_container_low` (#101b30) background. This creates a "recessed" look that feels organic.

### Ambient Shadows
When a floating effect is required (e.g., a Now Playing Mini-player), use a shadow with:
*   **Blur:** 40px - 60px
*   **Opacity:** 6%
*   **Color:** `on_surface` (#d7e2ff)
This mimics the way light catches the edge of a page rather than a harsh digital drop shadow.

### The "Ghost Border" Fallback
If accessibility requires a container edge, use a "Ghost Border": `outline_variant` (#44474d) at **15% opacity**. Never use 100% opaque lines.

---

## 5. Components

### Primary Playback Button
The heart of the app. 
*   **Shape:** `full` (9999px) for the main play action; `xl` (1.5rem) for secondary actions.
*   **Style:** `secondary` (#ffd795) background with `on_secondary` (#422c00) icon. 
*   **Interactivity:** On hover, apply a `secondary_container` (#fbb400) glow using a 20px ambient shadow.

### Book Cards & Lists
*   **Forbid Dividers:** Do not use lines to separate audiobooks in a list. Use `Spacing 4` (1.4rem) of vertical whitespace.
*   **The "Cover Lift":** Book covers should use `md` (0.75rem) rounded corners. When hovered, the cover should scale by 1.02 and gain a `surface_bright` (#2e394f) ambient glow.

### The Immersive Player (Custom Component)
Instead of a standard modal, the player uses **Glassmorphism**. Use `surface_container_highest` (#2a354b) with a `backdrop-blur` of 20px and 80% opacity. This allows the book cover art to bleed through the background, creating a personalized color mood for every story.

### Input Fields
*   **Background:** `surface_container_lowest` (#030e22).
*   **Corner:** `sm` (0.25rem) to maintain a slightly more structured, "archival" feel for utility.
*   **Active State:** Transition the "Ghost Border" from 15% to 40% opacity using the `primary` (#bac8dc) token.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical layouts. Place a large `display-sm` headline on the left with a `body-md` description offset to the right.
*   **Do** use "Warm Amber" (`secondary` tokens) sparingly. It should feel like a reward or a specific point of focus, not a primary brand color.
*   **Do** leverage `surface_dim` for late-night listening modes to reduce eye strain.

### Don’t:
*   **Don’t** use pure black (#000000) or pure white (#FFFFFF). Always use the themed neutrals provided in the `surface` and `on_surface` tokens to maintain the "Midnight" atmosphere.
*   **Don’t** crowd the UI. If you are unsure, add more `Spacing 8` or `Spacing 10`.
*   **Don’t** use "Default" button heights. Standardize on custom, tall touch targets (minimum 56px) for a premium, effortless feel.